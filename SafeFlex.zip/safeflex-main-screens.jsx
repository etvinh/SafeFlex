// safeflex-main-screens.jsx
// Dashboard, Exercises, Insights, Profile + sub-screens

const { useState, useEffect } = React;

// ─── Tokens ───────────────────────────────────────────────────────────────────
const D = {
  primary:    '#004AC6',
  priCon:     '#2563EB',
  surface:    '#FAF8FF',
  surfLow:    '#F3F3FE',
  surfCon:    '#EDEDF9',
  surfHigh:   '#E7E7F3',
  surfHighest:'#E1E2ED',
  onSurface:  '#191B23',
  onSurfVar:  '#434655',
  secondary:  '#585E6F',
  outline:    '#737686',
  outlineVar: '#C3C6D7',
  primFixed:  '#DBE1FF',
  primFixDim: '#B4C5FF',
  error:      '#BA1A1A',
  tertiary:   '#943700',
  success:    '#22C55E',
};

// Material Symbol
const MS = ({ n, size=22, fill=0, color='inherit', style={} }) => (
  <span style={{
    fontFamily:"'Material Symbols Outlined'", fontSize:size, fontStyle:'normal',
    fontWeight:400, lineHeight:1, userSelect:'none', color, display:'inline-block',
    fontVariationSettings:`'FILL' ${fill}, 'wght' 400, 'GRAD' 0, 'opsz' 24`,
    ...style
  }}>{n}</span>
);

// Glass card
const GC = ({ children, style={}, ...p }) => (
  <div style={{ background:'rgba(255,255,255,0.72)', backdropFilter:'blur(20px)',
    border:'1px solid rgba(255,255,255,0.35)', ...style }} {...p}>{children}</div>
);

// Avatar
const Av = ({ initials='SJ', size=32 }) => (
  <div style={{ width:size, height:size, borderRadius:'50%', background:D.primFixed,
    border:`1.5px solid ${D.primFixDim}`, display:'flex', alignItems:'center',
    justifyContent:'center', flexShrink:0 }}>
    <span style={{ fontSize:size*0.33, fontWeight:800, color:D.primary }}>{initials}</span>
  </div>
);

// 4-tab bottom nav
const MainNav = ({ active, onNav }) => {
  const tabs = [
    { id:'dashboard', n:'dashboard',      lbl:'Dashboard' },
    { id:'exercises', n:'fitness_center', lbl:'Exercises' },
    { id:'insights',  n:'insights',       lbl:'Insights'  },
    { id:'profile',   n:'person',         lbl:'Profile'   },
  ];
  return (
    <div style={{ position:'absolute', bottom:0, left:0, right:0, height:80,
      background:'rgba(255,255,255,0.9)', backdropFilter:'blur(20px)',
      borderTop:'1px solid rgba(255,255,255,0.3)',
      boxShadow:'0 -4px 20px rgba(37,99,235,0.04)',
      borderRadius:'16px 16px 0 0',
      display:'flex', alignItems:'flex-start', justifyContent:'space-around',
      paddingTop:10, zIndex:100 }}>
      {tabs.map(t => {
        const on = active === t.id;
        return (
          <button key={t.id} onClick={() => onNav(t.id)} style={{
            background: on ? 'rgba(219,225,255,0.55)' : 'none',
            border:'none', cursor:'pointer', padding:'6px 14px', borderRadius:10,
            display:'flex', flexDirection:'column', alignItems:'center', gap:2,
          }}>
            <MS n={t.n} fill={on?1:0} size={22} color={on ? D.primary : '#94A3B8'}/>
            <span style={{ fontSize:10, fontWeight:on?700:500, color:on?D.primary:'#94A3B8', whiteSpace:'nowrap' }}>{t.lbl}</span>
          </button>
        );
      })}
    </div>
  );
};

// ─── TOP APP BAR ──────────────────────────────────────────────────────────────
const TopBar = ({ title, left, right }) => (
  <div style={{ height:64, background:'rgba(255,255,255,0.8)', backdropFilter:'blur(16px)',
    borderBottom:'1px solid rgba(255,255,255,0.25)',
    boxShadow:'0 1px 2px rgba(37,99,235,0.04)',
    display:'flex', alignItems:'center', justifyContent:'space-between',
    padding:'0 20px', flexShrink:0 }}>
    <div>{left}</div>
    {title && <span style={{ fontSize:16, fontWeight:700, color:D.onSurface }}>{title}</span>}
    <div style={{ minWidth:40, display:'flex', justifyContent:'flex-end' }}>{right || null}</div>
  </div>
);

const SafeFlexLogo = () => (
  <div style={{ display:'flex', alignItems:'center', gap:8 }}>
    <MS n="menu" size={22} color={D.primary}/>
    <span style={{ fontSize:18, fontWeight:800, color:'#1D4ED8', letterSpacing:-0.5 }}>SafeFlex</span>
  </div>
);

const BackBtn = ({ onClick }) => (
  <button onClick={onClick} style={{ background:'none', border:'none', cursor:'pointer',
    color:D.primary, display:'flex', alignItems:'center', gap:4, fontSize:15, fontWeight:500, padding:0 }}>
    <MS n="arrow_back" size={20} color={D.primary}/>
    Back
  </button>
);

// ─── DASHBOARD ────────────────────────────────────────────────────────────────
function DashboardScreen({ onNav, onUpload, onStart }) {
  const days = [
    { lbl:'Mon', done:true,  num:21 },
    { lbl:'Tue', done:true,  num:22 },
    { lbl:'Wed', done:false, num:23, today:true },
    { lbl:'Thu', done:false, num:24 },
    { lbl:'Fri', done:false, num:25 },
    { lbl:'Sat', done:false, num:26 },
    { lbl:'Sun', done:false, num:27 },
  ];

  return (
    <div style={{ width:'100%', height:'100%', background:D.surface, display:'flex', flexDirection:'column', position:'relative' }}>
      <TopBar left={<SafeFlexLogo/>} right={<Av/>}/>

      <div style={{ flex:1, overflowY:'auto', padding:'16px 20px 96px' }}>
        {/* Greeting */}
        <div style={{ marginBottom:16 }}>
          <p style={{ fontSize:11, fontWeight:600, color:D.secondary, letterSpacing:0.9, textTransform:'uppercase' }}>
            {new Date().toLocaleDateString('en-US',{weekday:'long',month:'long',day:'numeric'})}
          </p>
          <h1 style={{ fontSize:30, fontWeight:800, color:D.onSurface, letterSpacing:-0.7, lineHeight:1.15 }}>Hello, Sarah</h1>
        </div>

        {/* Upload Protocol CTA */}
        <div onClick={onUpload} style={{ borderRadius:14, background:'rgba(219,225,255,0.3)',
          border:`2px dashed rgba(0,74,198,0.3)`, padding:'13px 15px',
          display:'flex', alignItems:'center', gap:13, marginBottom:12, cursor:'pointer',
          transition:'background 0.15s' }}>
          <div style={{ width:44, height:44, borderRadius:'50%', background:'rgba(0,74,198,0.1)',
            display:'flex', alignItems:'center', justifyContent:'center', flexShrink:0 }}>
            <MS n="upload_file" size={22} color={D.primary}/>
          </div>
          <div style={{ flex:1 }}>
            <div style={{ fontSize:13, fontWeight:700, color:D.onSurface }}>Upload Prescribed Protocol</div>
            <div style={{ fontSize:11, color:D.secondary, marginTop:1 }}>AI creates your exercise regimen automatically</div>
          </div>
          <MS n="add_circle" size={22} color={D.primary}/>
        </div>

        {/* Sensor status */}
        <GC style={{ borderRadius:14, padding:'13px 15px', display:'flex', alignItems:'center', gap:13, marginBottom:12 }}>
          <div style={{ width:44, height:44, borderRadius:'50%', background:D.primFixed,
            display:'flex', alignItems:'center', justifyContent:'center', flexShrink:0 }}>
            <MS n="settings_input_antenna" size={22} color={D.primary}/>
          </div>
          <div style={{ flex:1 }}>
            <div style={{ fontSize:13, fontWeight:700, color:D.onSurface }}>Sensor Status</div>
            <div style={{ fontSize:11, color:D.secondary }}>SafeFlex Band v2 Connected</div>
          </div>
          <div style={{ display:'flex', alignItems:'center', gap:5 }}>
            <div style={{ width:7, height:7, borderRadius:'50%', background:D.success,
              boxShadow:'0 0 6px rgba(34,197,94,0.7)', animation:'pulse 2s ease infinite' }}/>
            <span style={{ fontSize:11, fontWeight:700, color:D.primary }}>Active</span>
          </div>
        </GC>

        {/* Today's Plan */}
        <GC style={{ borderRadius:14, overflow:'hidden', marginBottom:12 }}>
          <div style={{ height:128, background:'linear-gradient(135deg, #1e3a6e 0%, #1d4ed8 100%)',
            position:'relative', display:'flex', alignItems:'flex-end', padding:'12px 14px' }}>
            <svg style={{ position:'absolute', right:16, top:'50%', transform:'translateY(-50%)', opacity:0.18 }} width="90" height="70" viewBox="0 0 90 70" fill="white">
              <circle cx="45" cy="14" r="10"/><rect x="28" y="28" width="34" height="5" rx="2.5"/>
              <rect x="36" y="33" width="5" height="28" rx="2.5"/><rect x="49" y="33" width="5" height="28" rx="2.5"/>
              <rect x="10" y="30" width="18" height="5" rx="2.5"/><rect x="62" y="30" width="18" height="5" rx="2.5"/>
            </svg>
            <div style={{ background:D.primary, borderRadius:99, padding:'3px 10px', zIndex:1 }}>
              <span style={{ fontSize:9, fontWeight:800, color:'#fff', letterSpacing:0.8 }}>RECOMMENDED</span>
            </div>
            <div style={{ position:'absolute', bottom:0, left:0, right:0, height:50,
              background:'linear-gradient(to top, rgba(255,255,255,1), transparent)' }}/>
          </div>
          <div style={{ padding:'12px 15px' }}>
            <div style={{ display:'flex', justifyContent:'space-between', alignItems:'flex-start', marginBottom:10 }}>
              <div>
                <div style={{ fontSize:17, fontWeight:700, color:D.onSurface }}>Today's Plan</div>
                <div style={{ fontSize:12, color:D.secondary }}>Focus: Shoulder Stability</div>
              </div>
              <div style={{ textAlign:'right' }}>
                <div style={{ fontSize:26, fontWeight:800, color:D.primary, letterSpacing:-1 }}>0%</div>
                <div style={{ fontSize:9, color:D.secondary }}>Complete</div>
              </div>
            </div>
            <div style={{ background:D.surfLow, borderRadius:10, padding:'9px 13px',
              display:'flex', alignItems:'center', gap:11, border:`1px solid ${D.outlineVar}30`, marginBottom:10 }}>
              <div style={{ width:34, height:34, borderRadius:8, background:'#fff',
                display:'flex', alignItems:'center', justifyContent:'center',
                boxShadow:'0 1px 3px rgba(0,0,0,0.06)', flexShrink:0 }}>
                <MS n="fitness_center" size={18} color={D.primary}/>
              </div>
              <div style={{ flex:1 }}>
                <div style={{ fontSize:13, fontWeight:600, color:D.onSurface }}>External Rotation</div>
                <div style={{ fontSize:11, color:D.secondary }}>3 Sets × 12 Reps</div>
              </div>
              <MS n="chevron_right" size={20} color={D.outline}/>
            </div>
            <div style={{ height:4, background:D.surfCon, borderRadius:99, overflow:'hidden' }}>
              <div style={{ height:'100%', width:'0%', background:D.primary, borderRadius:99 }}/>
            </div>
          </div>
        </GC>

        {/* Weekly adherence */}
        <GC style={{ borderRadius:14, padding:'14px 15px', marginBottom:12 }}>
          <div style={{ fontSize:14, fontWeight:700, color:D.onSurface, marginBottom:12 }}>Weekly Adherence</div>
          <div style={{ display:'flex', justifyContent:'space-between' }}>
            {days.map(d => (
              <div key={d.lbl} style={{ display:'flex', flexDirection:'column', alignItems:'center', gap:4 }}>
                <div style={{ width:36, height:36, borderRadius:'50%', flexShrink:0,
                  background: d.done ? D.primary : d.today ? D.primFixed : D.surfCon,
                  border: d.today ? `2px solid ${D.primary}` : '2px solid transparent',
                  display:'flex', alignItems:'center', justifyContent:'center',
                  opacity: (!d.done && !d.today) ? 0.45 : 1,
                  boxShadow: d.done ? '0 2px 6px rgba(0,74,198,0.28)' : 'none' }}>
                  {d.done
                    ? <MS n="check" size={16} fill={1} color="#fff"/>
                    : <span style={{ fontSize:11, fontWeight:600, color:d.today?D.primary:D.outline }}>{d.num}</span>}
                </div>
                <span style={{ fontSize:9, fontWeight:d.today?700:500,
                  color:d.today?D.primary:D.secondary, textTransform:'uppercase' }}>{d.lbl}</span>
              </div>
            ))}
          </div>
        </GC>

        {/* Stats */}
        <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr', gap:10 }}>
          <GC style={{ borderRadius:14, padding:'13px 15px', borderLeft:`4px solid ${D.primary}` }}>
            <div style={{ fontSize:11, color:D.secondary, marginBottom:3 }}>Pain Level</div>
            <div style={{ display:'flex', alignItems:'baseline', gap:2 }}>
              <span style={{ fontSize:22, fontWeight:700, color:D.onSurface }}>2.4</span>
              <span style={{ fontSize:11, color:D.secondary }}>/10</span>
            </div>
            <div style={{ display:'flex', alignItems:'center', gap:3, marginTop:5 }}>
              <MS n="trending_down" size={13} color={D.primary}/>
              <span style={{ fontSize:10, fontWeight:700, color:D.primary }}>−12%</span>
            </div>
          </GC>
          <GC style={{ borderRadius:14, padding:'13px 15px', borderLeft:`4px solid ${D.tertiary}` }}>
            <div style={{ fontSize:11, color:D.secondary, marginBottom:3 }}>Mobility</div>
            <div style={{ fontSize:22, fontWeight:700, color:D.onSurface }}>78°</div>
            <div style={{ display:'flex', alignItems:'center', gap:3, marginTop:5 }}>
              <MS n="trending_up" size={13} color={D.tertiary}/>
              <span style={{ fontSize:10, fontWeight:700, color:D.tertiary }}>+5°</span>
            </div>
          </GC>
        </div>
      </div>

      {/* FAB */}
      <button onClick={onStart} style={{ position:'absolute', bottom:90, right:16, zIndex:60,
        background:D.primary, color:'#fff', border:'none', borderRadius:99,
        padding:'12px 18px', display:'flex', alignItems:'center', gap:7, cursor:'pointer',
        boxShadow:'0 4px 20px rgba(0,74,198,0.45)', fontWeight:700, fontSize:13, letterSpacing:-0.2 }}>
        <MS n="play_arrow" size={18} fill={1} color="#fff"/>
        Start Session
      </button>

      <MainNav active="dashboard" onNav={onNav}/>
    </div>
  );
}

// ─── EXERCISES V2 ─────────────────────────────────────────────────────────────
function ExercisesScreenV2({ onNav, onStart }) {
  const [seg, setSeg] = useState('prescribed');

  return (
    <div style={{ width:'100%', height:'100%', background:D.surface, display:'flex', flexDirection:'column', position:'relative' }}>
      <TopBar left={<SafeFlexLogo/>} right={<Av/>}/>

      <div style={{ flex:1, overflowY:'auto', padding:'14px 20px 96px' }}>
        <div style={{ height:44, background:'#fff', borderRadius:12, border:`1px solid ${D.outlineVar}`,
          display:'flex', alignItems:'center', padding:'0 14px', gap:9, marginBottom:10,
          boxShadow:'0 1px 2px rgba(0,0,0,0.04)' }}>
          <MS n="search" size={18} color={D.outline}/>
          <span style={{ fontSize:14, color:D.outline }}>Search exercises...</span>
        </div>

        <div style={{ height:40, background:D.surfCon, borderRadius:10, padding:3, display:'flex', marginBottom:16 }}>
          {['prescribed','library'].map(t => (
            <button key={t} onClick={() => setSeg(t)} style={{
              flex:1, borderRadius:8, border:'none', cursor:'pointer', fontSize:12,
              fontWeight:seg===t?700:500,
              background:seg===t?'#fff':'transparent',
              color:seg===t?D.primary:D.onSurfVar,
              boxShadow:seg===t?'0 1px 3px rgba(0,0,0,0.07)':'none',
              transition:'all 0.18s',
            }}>{t==='prescribed'?'Prescribed':'Library'}</button>
          ))}
        </div>

        {seg === 'prescribed' ? (
          <>
            <div style={{ display:'flex', justifyContent:'space-between', alignItems:'center', marginBottom:10 }}>
              <span style={{ fontSize:20, fontWeight:800, color:D.onSurface, letterSpacing:-0.3 }}>Your Program</span>
              <span style={{ fontSize:11, fontWeight:700, color:D.primary }}>3 Total</span>
            </div>
            <GC style={{ borderRadius:14, padding:15, marginBottom:10, border:`1px solid rgba(0,74,198,0.1)` }}>
              <div style={{ display:'flex', justifyContent:'space-between', alignItems:'flex-start', marginBottom:11 }}>
                <div>
                  <div style={{ fontSize:18, fontWeight:800, color:D.onSurface, letterSpacing:-0.3 }}>Shoulder Abduction</div>
                  <div style={{ fontSize:9, fontWeight:600, color:D.outline, letterSpacing:0.9, marginTop:2 }}>UPPER BODY • RECOVERY</div>
                </div>
                <div style={{ background:'rgba(0,74,198,0.09)', borderRadius:99, padding:'3px 10px' }}>
                  <span style={{ fontSize:9, fontWeight:800, color:D.primary }}>TODAY</span>
                </div>
              </div>
              <div style={{ height:140, borderRadius:10, background:'linear-gradient(135deg,#EFF6FF,#DBEAFE)',
                display:'flex', alignItems:'center', justifyContent:'center', marginBottom:11,
                border:`1px solid rgba(0,74,198,0.08)`, position:'relative' }}>
                <svg width="110" height="80" viewBox="0 0 110 80" fill="none" opacity="0.45">
                  <circle cx="55" cy="15" r="10" stroke="#004AC6" strokeWidth="2"/>
                  <path d="M38 34h34" stroke="#004AC6" strokeWidth="3" strokeLinecap="round"/>
                  <path d="M47 34v32M63 34v32" stroke="#004AC6" strokeWidth="2.5" strokeLinecap="round"/>
                  <path d="M40 68h14M56 68h14" stroke="#004AC6" strokeWidth="2.5" strokeLinecap="round"/>
                  <path d="M18 36h20M72 36h20" stroke="#004AC6" strokeWidth="5" strokeLinecap="round"/>
                  <circle cx="13" cy="36" r="5" stroke="#004AC6" strokeWidth="2"/>
                  <circle cx="97" cy="36" r="5" stroke="#004AC6" strokeWidth="2"/>
                </svg>
                <span style={{ position:'absolute', bottom:7, fontSize:8, color:'rgba(0,74,198,0.35)', fontFamily:'monospace' }}>shoulder abduction demo</span>
              </div>
              <div style={{ display:'flex', justifyContent:'space-between', alignItems:'center',
                paddingTop:10, borderTop:`1px solid ${D.outlineVar}40` }}>
                <div style={{ display:'flex', gap:22 }}>
                  {[{l:'SETS',v:'3'},{l:'REPS',v:'12'}].map(m => (
                    <div key={m.l}>
                      <div style={{ fontSize:9, fontWeight:600, color:D.secondary, letterSpacing:0.5 }}>{m.l}</div>
                      <div style={{ fontSize:22, fontWeight:800, color:D.onSurface, letterSpacing:-0.5 }}>{m.v}</div>
                    </div>
                  ))}
                </div>
                <button onClick={onStart} style={{ height:36, padding:'0 18px', borderRadius:9, background:D.primary,
                  border:'none', color:'#fff', fontSize:13, fontWeight:700, cursor:'pointer',
                  display:'flex', alignItems:'center', gap:5, boxShadow:'0 2px 10px rgba(0,74,198,0.3)' }}>
                  <MS n="play_arrow" size={15} fill={1} color="#fff"/>Start
                </button>
              </div>
            </GC>
            {[
              { name:'Wrist Flexion', meta:'2 Sets • 15 Reps' },
              { name:'Neck Stretch',  meta:'3 Sets • 30s Hold' },
            ].map(e => (
              <div key={e.name} style={{ height:72, background:'#fff', borderRadius:12,
                border:`1px solid ${D.outlineVar}55`, display:'flex', alignItems:'center',
                padding:'0 14px', gap:12, marginBottom:8, boxShadow:'0 1px 2px rgba(0,0,0,0.04)' }}>
                <div style={{ width:44, height:44, borderRadius:10, background:'#EFF6FF', flexShrink:0,
                  display:'flex', alignItems:'center', justifyContent:'center' }}>
                  <MS n="fitness_center" size={20} color={D.primary}/>
                </div>
                <div style={{ flex:1 }}>
                  <div style={{ fontSize:14, fontWeight:700, color:D.onSurface }}>{e.name}</div>
                  <div style={{ fontSize:11, color:D.secondary, marginTop:2 }}>{e.meta}</div>
                </div>
                <button onClick={onStart} style={{ height:30, padding:'0 12px', borderRadius:8,
                  background:D.surfCon, border:'none', color:D.primary, fontSize:11, fontWeight:700, cursor:'pointer' }}>
                  Start
                </button>
              </div>
            ))}
          </>
        ) : (
          <>
            <div style={{ display:'flex', justifyContent:'space-between', alignItems:'center', marginBottom:10 }}>
              <span style={{ fontSize:18, fontWeight:800, color:D.onSurface }}>AI Recommended</span>
              <button style={{ background:'none', border:'none', color:D.primary, fontSize:12, fontWeight:600, cursor:'pointer' }}>Filter</button>
            </div>
            {[
              { name:'Hip Abduction',    cat:'Mobility • Lower Body', ic:'directions_walk' },
              { name:'Scapular Squeeze', cat:'Posture • Upper Body',  ic:'accessibility_new' },
              { name:'Bicep Curls',      cat:'Strength • Upper Body', ic:'fitness_center' },
              { name:'Quad Extension',   cat:'Strength • Lower Body', ic:'sports_gymnastics' },
            ].map(e => (
              <div key={e.name} style={{ height:68, background:'#fff', borderRadius:12,
                border:`1px solid ${D.outlineVar}50`, display:'flex', alignItems:'center',
                padding:'0 14px', gap:12, marginBottom:8, cursor:'pointer',
                boxShadow:'0 1px 2px rgba(0,0,0,0.04)' }}>
                <div style={{ width:44, height:44, borderRadius:10, background:D.surfLow, flexShrink:0,
                  display:'flex', alignItems:'center', justifyContent:'center' }}>
                  <MS n={e.ic} size={20} color={D.secondary}/>
                </div>
                <div style={{ flex:1 }}>
                  <div style={{ fontSize:14, fontWeight:600, color:D.onSurface }}>{e.name}</div>
                  <div style={{ fontSize:11, color:D.outline, marginTop:2 }}>{e.cat}</div>
                </div>
                <MS n="chevron_right" size={20} color={D.outline}/>
              </div>
            ))}
          </>
        )}
      </div>
      <MainNav active="exercises" onNav={onNav}/>
    </div>
  );
}

// ─── INSIGHTS ─────────────────────────────────────────────────────────────────
function InsightsScreen({ onNav }) {
  const romPts  = [72,78,82,80,88,92,90,98,95,102,100,108,105,112];
  const W=288, H=72;
  const max=Math.max(...romPts), min=Math.min(...romPts)-4;
  const xs = romPts.map((_,i) => (i/(romPts.length-1))*W);
  const ys = romPts.map(v => H - ((v-min)/(max-min+4))*(H-8) - 4);
  const line = xs.map((x,i) => `${i===0?'M':'L'}${x.toFixed(1)} ${ys[i].toFixed(1)}`).join(' ');
  const area = `${line} L${W} ${H} L0 ${H} Z`;

  const heatmap = Array.from({length:28}, (_,i) => {
    const v = [1,0.2,1,1,0.6,0.2,1, 0.8,1,1,0.2,1,0.6,1, 1,0.2,0.8,1,1,0.4,1, 0.6,1,1,0.2,1,0.8,0][i];
    return v;
  });

  return (
    <div style={{ width:'100%', height:'100%', background:D.surface, display:'flex', flexDirection:'column', position:'relative' }}>
      <TopBar left={<SafeFlexLogo/>} title="Insights" right={<Av/>}/>

      <div style={{ flex:1, overflowY:'auto', padding:'14px 20px 96px' }}>
        {/* Stats bento */}
        <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr', gap:10, marginBottom:16 }}>
          {[
            { ic:'analytics',   lbl:'Avg. Performance', val:'94%',  sub:'+2.4%',   sc:'#BC4800' },
            { ic:'rebase_edit', lbl:'Total Reps',        val:'1,248', sub:'this month', sc:D.outline },
          ].map(s => (
            <GC key={s.lbl} style={{ borderRadius:14, padding:'14px 15px',
              boxShadow:'0 4px 16px rgba(37,99,235,0.04)' }}>
              <div style={{ display:'flex', alignItems:'center', gap:6, marginBottom:7 }}>
                <MS n={s.ic} size={18} color={D.primary}/>
                <span style={{ fontSize:9, fontWeight:600, color:D.outline, letterSpacing:0.7, textTransform:'uppercase' }}>{s.lbl}</span>
              </div>
              <div style={{ display:'flex', alignItems:'baseline', gap:6 }}>
                <span style={{ fontSize:30, fontWeight:800, color:D.primary, letterSpacing:-1 }}>{s.val}</span>
                <span style={{ fontSize:11, fontWeight:600, color:s.sc }}>{s.sub}</span>
              </div>
            </GC>
          ))}
        </div>

        {/* ROM Chart */}
        <GC style={{ borderRadius:14, padding:'15px 15px', marginBottom:12, boxShadow:'0 4px 16px rgba(37,99,235,0.04)' }}>
          <div style={{ display:'flex', justifyContent:'space-between', alignItems:'flex-start', marginBottom:12 }}>
            <div>
              <div style={{ fontSize:16, fontWeight:700, color:D.onSurface }}>Range of Motion</div>
              <div style={{ fontSize:11, color:D.outline }}>Progress over the last 14 days</div>
            </div>
            <MS n="info" size={20} color={D.outline}/>
          </div>
          <div style={{ position:'relative', paddingLeft:28 }}>
            <div style={{ position:'absolute', left:0, top:0, bottom:0, display:'flex', flexDirection:'column', justifyContent:'space-between', paddingBottom:2 }}>
              {['120°','90°','60°','30°'].map(l => <span key={l} style={{ fontSize:8, color:D.outline }}>{l}</span>)}
            </div>
            <svg width={W} height={H} viewBox={`0 0 ${W} ${H}`} style={{ overflow:'visible' }}>
              <defs>
                <linearGradient id="romGrad" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="0%" stopColor={D.primary} stopOpacity="0.12"/>
                  <stop offset="100%" stopColor={D.primary} stopOpacity="0"/>
                </linearGradient>
              </defs>
              <path d={area} fill="url(#romGrad)"/>
              <path d={line} fill="none" stroke={D.primary} strokeWidth="2.2" strokeLinejoin="round" strokeLinecap="round"/>
              <circle cx={xs[xs.length-1]} cy={ys[ys.length-1]} r="4" fill={D.primary} stroke="white" strokeWidth="1.5"/>
            </svg>
          </div>
          <div style={{ display:'flex', justifyContent:'space-between', marginTop:6, paddingLeft:28 }}>
            {['Mon','Wed','Fri','Sun','Tue','Thu','Today'].map((l,i) => (
              <span key={i} style={{ fontSize:9, color: i===6?D.primary:D.outline, fontWeight:i===6?700:400 }}>{l}</span>
            ))}
          </div>
        </GC>

        {/* Stability + Adherence row */}
        <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr', gap:10, marginBottom:12 }}>
          {/* Stability */}
          <GC style={{ borderRadius:14, padding:'14px 14px', boxShadow:'0 4px 16px rgba(37,99,235,0.04)' }}>
            <div style={{ fontSize:14, fontWeight:700, color:D.onSurface, marginBottom:2 }}>Stability</div>
            <div style={{ fontSize:11, color:D.outline, marginBottom:12 }}>Balance & control</div>
            {[{lbl:'Knee Stability', pct:85},{lbl:'Joint Load', pct:92, col:'#BC4800'}].map(b => (
              <div key={b.lbl} style={{ marginBottom:10 }}>
                <div style={{ display:'flex', justifyContent:'space-between', marginBottom:5 }}>
                  <span style={{ fontSize:11, color:D.onSurface }}>{b.lbl}</span>
                  <span style={{ fontSize:11, fontWeight:600, color:b.col||D.primary }}>{b.pct}%</span>
                </div>
                <div style={{ height:6, background:D.surfCon, borderRadius:99, overflow:'hidden' }}>
                  <div style={{ height:'100%', width:`${b.pct}%`, background:b.col||D.primary, borderRadius:99 }}/>
                </div>
              </div>
            ))}
          </GC>

          {/* Adherence heatmap */}
          <GC style={{ borderRadius:14, padding:'14px 14px', boxShadow:'0 4px 16px rgba(37,99,235,0.04)' }}>
            <div style={{ fontSize:14, fontWeight:700, color:D.onSurface, marginBottom:2 }}>Adherence</div>
            <div style={{ fontSize:11, color:D.outline, marginBottom:10 }}>Last 28 days</div>
            <div style={{ display:'grid', gridTemplateColumns:'repeat(7,1fr)', gap:3 }}>
              {heatmap.map((v,i) => (
                <div key={i} style={{ aspectRatio:'1', borderRadius:3,
                  background: v > 0.5 ? `rgba(0,74,198,${v})` : v > 0 ? `rgba(0,74,198,${v+0.1})` : D.surfHigh,
                  border: v === 0 ? `1px solid ${D.outlineVar}40` : 'none',
                }}/>
              ))}
            </div>
            <div style={{ display:'flex', justifyContent:'space-between', alignItems:'center', marginTop:8 }}>
              <span style={{ fontSize:8, color:D.outline }}>Less</span>
              <div style={{ display:'flex', gap:3 }}>
                {[0.15,0.35,0.65,1].map(o => (
                  <div key={o} style={{ width:8, height:8, borderRadius:2, background:`rgba(0,74,198,${o})` }}/>
                ))}
              </div>
              <span style={{ fontSize:8, color:D.outline }}>More</span>
            </div>
          </GC>
        </div>

        {/* Therapist note */}
        <GC style={{ borderRadius:14, padding:'13px 15px', background:'rgba(219,225,255,0.35)',
          border:`1px solid rgba(0,74,198,0.12)`, boxShadow:'0 4px 16px rgba(37,99,235,0.04)' }}>
          <div style={{ display:'flex', alignItems:'flex-start', gap:12 }}>
            <div style={{ width:38, height:38, borderRadius:10, background:'rgba(0,74,198,0.1)',
              display:'flex', alignItems:'center', justifyContent:'center', flexShrink:0 }}>
              <MS n="clinical_notes" size={20} color={D.primary}/>
            </div>
            <div>
              <div style={{ fontSize:14, fontWeight:700, color:D.primary, marginBottom:4 }}>Therapist Recommendation</div>
              <p style={{ fontSize:13, color:D.onSurfVar, lineHeight:1.55, fontStyle:'italic' }}>
                "Great improvement in knee flexion. Focus on slow eccentric movements for the next 48 hours to manage load."
              </p>
            </div>
          </div>
        </GC>
      </div>

      <MainNav active="insights" onNav={onNav}/>
    </div>
  );
}

// ─── PROFILE ──────────────────────────────────────────────────────────────────
function ProfileScreen({ onNav, onDeviceSettings, onPersonalInfo }) {
  return (
    <div style={{ width:'100%', height:'100%', background:D.surface, display:'flex', flexDirection:'column', position:'relative' }}>
      <TopBar left={<SafeFlexLogo/>} right={<Av/>}/>

      <div style={{ flex:1, overflowY:'auto', padding:'16px 20px 96px' }}>
        {/* User header */}
        <div style={{ display:'flex', alignItems:'center', gap:14, marginBottom:22 }}>
          <div style={{ position:'relative' }}>
            <div style={{ width:72, height:72, borderRadius:'50%', background:'linear-gradient(135deg,#DBEAFE,#EFF6FF)',
              border:`2px solid ${D.primary}`, display:'flex', alignItems:'center', justifyContent:'center' }}>
              <span style={{ fontSize:26, fontWeight:800, color:D.primary }}>SJ</span>
            </div>
            <div style={{ position:'absolute', bottom:0, right:0, width:22, height:22, borderRadius:'50%',
              background:D.primary, display:'flex', alignItems:'center', justifyContent:'center',
              border:'2px solid white' }}>
              <MS n="edit" size={13} color="#fff"/>
            </div>
          </div>
          <div>
            <div style={{ fontSize:24, fontWeight:700, color:D.onSurface, letterSpacing:-0.4 }}>Sarah Jenkins</div>
            <div style={{ fontSize:12, color:D.secondary }}>Patient ID: SF-8829-X</div>
          </div>
        </div>

        {/* Account Settings */}
        <div style={{ marginBottom:18 }}>
          <p style={{ fontSize:11, fontWeight:600, color:D.onSurfVar, letterSpacing:0.6, marginBottom:8, paddingLeft:2 }}>ACCOUNT SETTINGS</p>
          <div style={{ background:D.surfLow, borderRadius:14, overflow:'hidden', border:`1px solid ${D.outlineVar}30` }}>
            {[
              { lbl:'Personal Information', ic:'person',        onClick:onPersonalInfo },
              { lbl:'Notification Preferences', ic:'notifications', onClick:()=>{} },
            ].map((r,i) => (
              <div key={r.lbl}>
                {i > 0 && <div style={{ height:1, background:`${D.outlineVar}30`, margin:'0 16px' }}/>}
                <div onClick={r.onClick} style={{ display:'flex', alignItems:'center', justifyContent:'space-between',
                  padding:'14px 16px', cursor:'pointer' }}>
                  <div style={{ display:'flex', alignItems:'center', gap:14 }}>
                    <div style={{ width:38, height:38, borderRadius:10, background:`${D.primFixed}50`,
                      display:'flex', alignItems:'center', justifyContent:'center' }}>
                      <MS n={r.ic} size={20} color={D.primary}/>
                    </div>
                    <span style={{ fontSize:15, color:D.onSurface }}>{r.lbl}</span>
                  </div>
                  <MS n="chevron_right" size={20} color={D.outline}/>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Health & Privacy */}
        <div style={{ marginBottom:18 }}>
          <p style={{ fontSize:11, fontWeight:600, color:D.onSurfVar, letterSpacing:0.6, marginBottom:8, paddingLeft:2 }}>HEALTH & PRIVACY</p>
          <div style={{ background:D.surfLow, borderRadius:14, overflow:'hidden', border:`1px solid ${D.outlineVar}30` }}>
            <div style={{ display:'flex', alignItems:'center', justifyContent:'space-between', padding:'13px 16px' }}>
              <div style={{ display:'flex', alignItems:'center', gap:14 }}>
                <div style={{ width:38, height:38, borderRadius:10, background:'rgba(255,219,205,0.5)',
                  display:'flex', alignItems:'center', justifyContent:'center' }}>
                  <MS n="favorite" size={20} color={D.tertiary}/>
                </div>
                <div>
                  <div style={{ fontSize:15, color:D.onSurface }}>Apple HealthKit Sync</div>
                  <div style={{ fontSize:11, color:D.secondary }}>Sync your recovery metrics</div>
                </div>
              </div>
              <div style={{ width:46, height:26, borderRadius:99, background:D.primary, position:'relative',
                display:'flex', alignItems:'center', padding:'0 3px', justifyContent:'flex-end' }}>
                <div style={{ width:20, height:20, borderRadius:'50%', background:'#fff' }}/>
              </div>
            </div>
            <div style={{ height:1, background:`${D.outlineVar}30`, margin:'0 16px' }}/>
            <div style={{ display:'flex', alignItems:'center', justifyContent:'space-between', padding:'13px 16px', cursor:'pointer' }}>
              <div style={{ display:'flex', alignItems:'center', gap:14 }}>
                <div style={{ width:38, height:38, borderRadius:10, background:'rgba(255,219,205,0.5)',
                  display:'flex', alignItems:'center', justifyContent:'center' }}>
                  <MS n="lock" size={20} color={D.tertiary}/>
                </div>
                <span style={{ fontSize:15, color:D.onSurface }}>Privacy & Data Sharing</span>
              </div>
              <MS n="chevron_right" size={20} color={D.outline}/>
            </div>
          </div>
        </div>

        {/* Device Settings */}
        <div style={{ marginBottom:18 }}>
          <p style={{ fontSize:11, fontWeight:600, color:D.onSurfVar, letterSpacing:0.6, marginBottom:8, paddingLeft:2 }}>DEVICE SETTINGS</p>
          <div style={{ background:D.surfLow, borderRadius:14, padding:'14px 16px', border:`1px solid ${D.outlineVar}30` }}>
            <div style={{ display:'flex', alignItems:'center', justifyContent:'space-between', marginBottom:10 }}>
              <div style={{ display:'flex', alignItems:'center', gap:12 }}>
                <div style={{ width:44, height:44, borderRadius:'50%', background:D.surfHighest,
                  display:'flex', alignItems:'center', justifyContent:'center' }}>
                  <MS n="watch" size={24} color={D.primary}/>
                </div>
                <div>
                  <div style={{ fontSize:14, fontWeight:700, color:D.onSurface }}>SafeFlex Band v2</div>
                  <div style={{ fontSize:11, fontWeight:600, color:D.primary }}>Connected • 84% Battery</div>
                </div>
              </div>
              <button onClick={onDeviceSettings} style={{ height:32, padding:'0 12px', borderRadius:8,
                background:D.surfCon, border:`1px solid rgba(0,74,198,0.18)`,
                color:D.primary, fontSize:12, fontWeight:600, cursor:'pointer' }}>
                Manage
              </button>
            </div>
            <div style={{ background:'rgba(255,255,255,0.55)', borderRadius:8, padding:'8px 10px',
              display:'flex', alignItems:'center', gap:7 }}>
              <MS n="info" size={14} color={D.outline}/>
              <span style={{ fontSize:10, color:D.secondary }}>Last synchronized: Today at 9:41 AM</span>
            </div>
          </div>
        </div>

        {/* Care Team */}
        <div style={{ marginBottom:22 }}>
          <p style={{ fontSize:11, fontWeight:600, color:D.onSurfVar, letterSpacing:0.6, marginBottom:8, paddingLeft:2 }}>CARE TEAM</p>
          <div style={{ background:D.surfLow, borderRadius:14, padding:'14px 16px',
            border:`1px solid ${D.outlineVar}30`, display:'flex', alignItems:'center', justifyContent:'space-between' }}>
            <div style={{ display:'flex', alignItems:'center', gap:12 }}>
              <div style={{ width:44, height:44, borderRadius:'50%', background:'linear-gradient(135deg,#DBEAFE,#EFF6FF)',
                border:`1px solid ${D.outlineVar}40`, display:'flex', alignItems:'center', justifyContent:'center' }}>
                <span style={{ fontSize:16, fontWeight:800, color:D.primary }}>MC</span>
              </div>
              <div>
                <div style={{ fontSize:14, fontWeight:700, color:D.onSurface }}>Dr. Michael Chen</div>
                <div style={{ fontSize:11, color:D.secondary }}>Lead Physical Therapist</div>
              </div>
            </div>
            <div style={{ display:'flex', gap:8 }}>
              {['chat_bubble','call'].map(ic => (
                <button key={ic} style={{ width:38, height:38, borderRadius:'50%', background:`${D.primFixed}50`,
                  border:'none', display:'flex', alignItems:'center', justifyContent:'center', cursor:'pointer' }}>
                  <MS n={ic} size={18} color={D.primary}/>
                </button>
              ))}
            </div>
          </div>
        </div>

        {/* Sign out */}
        <button style={{ width:'100%', height:50, borderRadius:12, background:'#fff',
          border:`1px solid rgba(186,26,26,0.2)`, color:D.error,
          fontSize:16, fontWeight:600, cursor:'pointer', marginBottom:6 }}>
          Sign Out
        </button>
        <p style={{ textAlign:'center', fontSize:10, color:D.outline }}>SafeFlex App v4.2.1-stable</p>
      </div>

      <MainNav active="profile" onNav={onNav}/>
    </div>
  );
}

// ─── DEVICE SETTINGS ──────────────────────────────────────────────────────────
function DeviceSettingsScreen({ onBack }) {
  const [autoSync, setAutoSync] = useState(true);
  const R=22, circ=2*Math.PI*R;

  return (
    <div style={{ width:'100%', height:'100%', background:D.surface, display:'flex', flexDirection:'column', position:'relative' }}>
      <TopBar left={<BackBtn onClick={onBack}/>} title="Device Settings" right={
        <div style={{ width:30, height:30, borderRadius:'50%', background:D.surfHigh,
          border:`1px solid ${D.outlineVar}`, display:'flex', alignItems:'center', justifyContent:'center', overflow:'hidden' }}>
          <span style={{ fontSize:11, fontWeight:700, color:D.primary }}>SJ</span>
        </div>
      }/>

      <div style={{ flex:1, overflowY:'auto', padding:'16px 20px 32px' }}>
        {/* Device hero */}
        <GC style={{ borderRadius:14, padding:'16px 16px', marginBottom:18,
          boxShadow:'0 4px 16px rgba(0,83,219,0.04)', display:'flex', justifyContent:'space-between', alignItems:'center' }}>
          <div>
            <div style={{ display:'inline-flex', alignItems:'center', gap:5, background:'#F0FDF4',
              border:'1px solid #BBF7D0', borderRadius:99, padding:'2px 8px', marginBottom:6 }}>
              <div style={{ width:6, height:6, borderRadius:'50%', background:'#16A34A' }}/>
              <span style={{ fontSize:10, fontWeight:700, color:'#15803D' }}>Active</span>
            </div>
            <div style={{ fontSize:18, fontWeight:700, color:D.onSurface, letterSpacing:-0.3 }}>SafeFlex Band v2</div>
            <div style={{ fontSize:11, color:D.secondary }}>Bluetooth LE Connected</div>
          </div>
          {/* Battery ring */}
          <div style={{ position:'relative', width:52, height:52, display:'flex', alignItems:'center', justifyContent:'center' }}>
            <svg width="52" height="52" viewBox="0 0 52 52" style={{ transform:'rotate(-90deg)' }}>
              <circle cx="26" cy="26" r={R} fill="none" stroke={D.surfCon} strokeWidth="4"/>
              <circle cx="26" cy="26" r={R} fill="none" stroke={D.primary}
                strokeWidth="4" strokeLinecap="round"
                strokeDasharray={circ} strokeDashoffset={circ * 0.16}/>
            </svg>
            <div style={{ position:'absolute', display:'flex', flexDirection:'column', alignItems:'center' }}>
              <span style={{ fontSize:12, fontWeight:800, color:D.onSurface, lineHeight:1 }}>84%</span>
              <MS n="bolt" size={10} color={D.primary}/>
            </div>
          </div>
        </GC>

        {/* Device Actions */}
        <p style={{ fontSize:11, fontWeight:600, color:D.onSurfVar, letterSpacing:0.6, marginBottom:8, paddingLeft:2 }}>DEVICE ACTIONS</p>
        <GC style={{ borderRadius:14, marginBottom:18, overflow:'hidden' }}>
          {[
            { ic:'rebase_edit', lbl:'Recalibrate Sensors', sub:'Adjust accuracy for therapy', col:D.primary },
            { ic:'query_stats', lbl:'Firmware Update', sub:'v2.4.1 Stable available', badge:'NEW', col:D.primary },
          ].map((a,i) => (
            <div key={a.lbl}>
              {i > 0 && <div style={{ height:1, background:`${D.outlineVar}30`, margin:'0 16px' }}/>}
              <div style={{ display:'flex', alignItems:'center', gap:14, padding:'13px 16px', cursor:'pointer' }}>
                <div style={{ width:38, height:38, borderRadius:10, background:'rgba(0,74,198,0.08)',
                  display:'flex', alignItems:'center', justifyContent:'center', flexShrink:0 }}>
                  <MS n={a.ic} size={20} color={a.col}/>
                </div>
                <div style={{ flex:1 }}>
                  <div style={{ display:'flex', alignItems:'center', gap:7 }}>
                    <span style={{ fontSize:15, color:D.onSurface }}>{a.lbl}</span>
                    {a.badge && <span style={{ fontSize:9, fontWeight:800, background:D.priCon,
                      color:'#fff', padding:'2px 5px', borderRadius:4 }}>{a.badge}</span>}
                  </div>
                  <div style={{ fontSize:11, color:D.secondary }}>{a.sub}</div>
                </div>
                <MS n="chevron_right" size={20} color={D.outline}/>
              </div>
            </div>
          ))}
        </GC>

        {/* Connectivity */}
        <p style={{ fontSize:11, fontWeight:600, color:D.onSurfVar, letterSpacing:0.6, marginBottom:8, paddingLeft:2 }}>CONNECTIVITY</p>
        <GC style={{ borderRadius:14, marginBottom:18, overflow:'hidden' }}>
          <div style={{ display:'flex', alignItems:'center', justifyContent:'space-between', padding:'13px 16px' }}>
            <div style={{ display:'flex', alignItems:'center', gap:14 }}>
              <div style={{ width:38, height:38, borderRadius:10, background:'rgba(0,74,198,0.08)',
                display:'flex', alignItems:'center', justifyContent:'center' }}>
                <MS n="sync" size={20} color={D.primary}/>
              </div>
              <div>
                <div style={{ fontSize:15, color:D.onSurface }}>Auto-Sync Data</div>
                <div style={{ fontSize:11, color:D.secondary }}>Real-time clinical updates</div>
              </div>
            </div>
            <div onClick={() => setAutoSync(!autoSync)} style={{ width:46, height:26, borderRadius:99,
              background: autoSync ? D.primary : D.outlineVar,
              position:'relative', display:'flex', alignItems:'center', padding:'0 3px',
              justifyContent: autoSync ? 'flex-end' : 'flex-start', cursor:'pointer',
              transition:'all 0.2s' }}>
              <div style={{ width:20, height:20, borderRadius:'50%', background:'#fff',
                boxShadow:'0 1px 3px rgba(0,0,0,0.15)' }}/>
            </div>
          </div>
          <div style={{ height:1, background:`${D.outlineVar}30`, margin:'0 16px' }}/>
          <div style={{ display:'flex', alignItems:'center', gap:14, padding:'13px 16px', cursor:'pointer' }}>
            <div style={{ width:38, height:38, borderRadius:10, background:'rgba(186,26,26,0.08)',
              display:'flex', alignItems:'center', justifyContent:'center' }}>
              <MS n="link_off" size={20} color={D.error}/>
            </div>
            <div style={{ flex:1 }}>
              <div style={{ fontSize:15, color:D.error }}>Disconnect Device</div>
              <div style={{ fontSize:11, color:`${D.error}99` }}>Unpair from this smartphone</div>
            </div>
            <MS n="chevron_right" size={20} color={`${D.error}55`}/>
          </div>
        </GC>

        {/* Technical Details */}
        <p style={{ fontSize:11, fontWeight:600, color:D.onSurfVar, letterSpacing:0.6, marginBottom:8, paddingLeft:2 }}>TECHNICAL DETAILS</p>
        <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr', gap:10 }}>
          {[
            { lbl:'Serial Number', val:'SF-2024-9982-A', mono:true },
            { lbl:'Hardware Rev',  val:'REV_E_04',       mono:true },
          ].map(d => (
            <div key={d.lbl} style={{ background:D.surfLow, borderRadius:12, padding:'12px 13px',
              border:`1px solid ${D.surfHighest}` }}>
              <div style={{ fontSize:11, color:D.onSurfVar }}>{d.lbl}</div>
              <div style={{ fontSize:13, fontWeight:700, color:D.onSurface, marginTop:4,
                fontFamily:d.mono?'monospace':'inherit' }}>{d.val}</div>
            </div>
          ))}
          <div style={{ background:D.surfLow, borderRadius:12, padding:'12px 13px',
            border:`1px solid ${D.surfHighest}`, gridColumn:'span 2',
            display:'flex', alignItems:'center', justifyContent:'space-between' }}>
            <div>
              <div style={{ fontSize:11, color:D.onSurfVar }}>FDA Compliance</div>
              <div style={{ fontSize:14, fontWeight:600, color:D.onSurface, marginTop:4 }}>Class II Therapeutic Device</div>
            </div>
            <MS n="verified" size={24} color={`${D.primary}55`}/>
          </div>
        </div>
      </div>
    </div>
  );
}

// ─── PERSONAL INFO ────────────────────────────────────────────────────────────
function PersonalInfoScreen({ onBack }) {
  const [form, setForm] = useState({ name:'Alex Johnson', dob:'May 14, 1988', email:'alex@safeflex.com', phone:'+1 (555) 123-4567', ename:'Sarah Johnson', ephone:'+1 (555) 987-6543' });
  const [saved, setSaved] = useState(false);
  const set = k => e => setForm(v => ({...v, [k]:e.target.value}));

  const inputSt = { height:46, borderRadius:9, background:'rgba(255,255,255,0.65)',
    border:`1px solid ${D.outlineVar}`, padding:'0 13px', fontSize:14, outline:'none',
    color:D.onSurface, width:'100%', fontFamily:"'Inter', -apple-system, sans-serif",
    transition:'border-color 0.15s' };

  const Section = ({ ic, title, col=D.primary, bg='rgba(219,225,255,0.3)', children }) => (
    <div style={{ background:'rgba(255,255,255,0.72)', backdropFilter:'blur(20px)',
      border:'1px solid rgba(255,255,255,0.45)', borderRadius:14, padding:'16px 16px',
      boxShadow:'0 4px 16px rgba(0,83,219,0.04)', marginBottom:14 }}>
      <div style={{ display:'flex', alignItems:'center', gap:8, marginBottom:14 }}>
        <MS n={ic} size={20} color={col}/>
        <span style={{ fontSize:11, fontWeight:700, color:col, letterSpacing:0.8, textTransform:'uppercase' }}>{title}</span>
      </div>
      <div style={{ display:'flex', flexDirection:'column', gap:10 }}>{children}</div>
    </div>
  );

  const Field = ({ label, k, type='text', placeholder='' }) => (
    <div style={{ display:'flex', flexDirection:'column', gap:5 }}>
      <label style={{ fontSize:11, fontWeight:500, color:D.onSurfVar, paddingLeft:2 }}>{label}</label>
      <div style={{ position:'relative' }}>
        <input value={form[k]} onChange={set(k)} type={type} placeholder={placeholder} style={inputSt}/>
        {k === 'dob' && <MS n="calendar_today" size={16} color={D.outline} style={{ position:'absolute', right:12, top:'50%', transform:'translateY(-50%)' }}/>}
      </div>
    </div>
  );

  return (
    <div style={{ width:'100%', height:'100%', background:D.surface, display:'flex', flexDirection:'column', position:'relative' }}>
      <TopBar left={<BackBtn onClick={onBack}/>} title="Edit Personal Info"/>

      <div style={{ flex:1, overflowY:'auto', padding:'16px 20px 32px' }}>
        {/* Avatar */}
        <div style={{ display:'flex', flexDirection:'column', alignItems:'center', padding:'16px 0 20px' }}>
          <div style={{ position:'relative' }}>
            <div style={{ width:96, height:96, borderRadius:'50%', background:'linear-gradient(135deg,#DBEAFE,#EFF6FF)',
              border:`3px solid white`, boxShadow:'0 4px 16px rgba(0,0,0,0.1)',
              display:'flex', alignItems:'center', justifyContent:'center' }}>
              <span style={{ fontSize:34, fontWeight:800, color:D.primary }}>AJ</span>
            </div>
            <div style={{ position:'absolute', bottom:0, right:0, width:30, height:30, borderRadius:'50%',
              background:D.priCon, display:'flex', alignItems:'center', justifyContent:'center',
              border:'2px solid white', boxShadow:'0 2px 8px rgba(37,99,235,0.4)', cursor:'pointer' }}>
              <MS n="edit" size={14} color="#fff"/>
            </div>
          </div>
          <div style={{ fontSize:18, fontWeight:700, color:D.onSurface, marginTop:10 }}>Alex Johnson</div>
          <div style={{ fontSize:11, color:D.secondary }}>Patient ID: SF-2934-PT</div>
        </div>

        <Section ic="badge" title="Identity">
          <Field label="Full Name" k="name" placeholder="Alex Johnson"/>
          <Field label="Date of Birth" k="dob" placeholder="May 14, 1988"/>
        </Section>

        <Section ic="contact_mail" title="Contact Details">
          <Field label="Email Address" k="email" type="email" placeholder="alex@safeflex.com"/>
          <Field label="Phone Number" k="phone" type="tel" placeholder="+1 (555) 123-4567"/>
        </Section>

        <Section ic="emergency_share" title="Emergency Contact" col={D.error} bg="rgba(186,26,26,0.04)">
          <Field label="Contact Name" k="ename" placeholder="Sarah Johnson"/>
          <Field label="Contact Phone" k="ephone" type="tel" placeholder="+1 (555) 987-6543"/>
        </Section>

        <button onClick={() => { setSaved(true); setTimeout(() => setSaved(false), 2500); }} style={{
          width:'100%', height:52, borderRadius:13, background: saved ? '#15803D' : D.primary,
          border:'none', color:'#fff', fontSize:16, fontWeight:700, cursor:'pointer',
          display:'flex', alignItems:'center', justifyContent:'center', gap:8,
          boxShadow:`0 4px 16px ${D.primary}40`, transition:'background 0.3s',
        }}>
          <MS n={saved?"check":"save"} size={20} color="#fff"/>
          {saved ? 'Saved!' : 'Save Changes'}
        </button>
        <p style={{ textAlign:'center', fontSize:11, color:D.outline, marginTop:12, lineHeight:1.5 }}>
          Your data is encrypted and stored securely.
        </p>
      </div>
    </div>
  );
}

// ─── UPLOAD PROTOCOL ──────────────────────────────────────────────────────────
function UploadProtocolScreen({ onBack }) {
  const [scanning, setScanning] = useState(false);
  const [done, setDone] = useState(false);
  const [progress, setProgress] = useState(0);

  const startScan = () => {
    setScanning(true); setProgress(0);
    const t = setInterval(() => {
      setProgress(p => {
        if (p >= 100) { clearInterval(t); setScanning(false); setDone(true); return 100; }
        return p + 7;
      });
    }, 200);
  };

  return (
    <div style={{ width:'100%', height:'100%', background:D.surface, display:'flex', flexDirection:'column', position:'relative' }}>
      <TopBar left={<BackBtn onClick={onBack}/>} title="TherapyPulse"/>

      <div style={{ flex:1, overflowY:'auto', padding:'20px 20px 32px' }}>
        <div style={{ marginBottom:18 }}>
          <h2 style={{ fontSize:30, fontWeight:800, color:D.primary, letterSpacing:-0.8 }}>Upload Protocol</h2>
          <p style={{ fontSize:15, color:D.secondary, marginTop:4 }}>Digitize your recovery plan with medical-grade precision.</p>
        </div>

        {/* AI Engine card */}
        <GC style={{ borderRadius:14, padding:'15px 15px', marginBottom:16,
          border:`1px solid rgba(0,74,198,0.1)`, boxShadow:'0 4px 16px rgba(37,99,235,0.04)' }}>
          <div style={{ display:'flex', gap:14, alignItems:'flex-start' }}>
            <div style={{ width:44, height:44, borderRadius:12, background:D.primFixed, flexShrink:0,
              display:'flex', alignItems:'center', justifyContent:'center' }}>
              <MS n="clinical_notes" size={22} color={D.primary}/>
            </div>
            <div>
              <div style={{ fontSize:16, fontWeight:700, color:D.onSurface, marginBottom:5 }}>AI Processing Engine</div>
              <p style={{ fontSize:13, color:D.onSurfVar, lineHeight:1.6 }}>
                Our clinical AI scans your PDF to identify exercises, frequency, and safety precautions — creating a structured, interactive regimen tailored to your doctor's orders.
              </p>
            </div>
          </div>
        </GC>

        {/* Upload zone */}
        {!done ? (
          <div style={{ borderRadius:14, border:`2px dashed rgba(0,74,198,0.22)`,
            background:'rgba(219,225,255,0.12)', padding:'36px 20px',
            display:'flex', flexDirection:'column', alignItems:'center', gap:12, marginBottom:16,
            cursor:'pointer', position:'relative' }}>
            <div style={{ width:72, height:72, borderRadius:'50%', background:'rgba(0,74,198,0.08)',
              display:'flex', alignItems:'center', justifyContent:'center' }}>
              <MS n="upload_file" size={34} color={D.primary}/>
            </div>
            <div style={{ textAlign:'center' }}>
              <div style={{ fontSize:16, fontWeight:700, color:D.primary }}>Drag and drop your PDF</div>
              <div style={{ fontSize:13, color:D.outline, marginTop:3 }}>or tap to browse local files</div>
            </div>
            <div style={{ background:D.surfCon, borderRadius:99, padding:'5px 14px' }}>
              <span style={{ fontSize:11, color:D.onSurfVar }}>Supported: PDF (Max 25MB)</span>
            </div>
          </div>
        ) : (
          <GC style={{ borderRadius:14, padding:'20px 16px', marginBottom:16, textAlign:'center',
            background:'rgba(240,253,244,0.8)', border:'1px solid #BBF7D0' }}>
            <div style={{ width:56, height:56, borderRadius:'50%', background:'#F0FDF4',
              border:'2px solid #BBF7D0', margin:'0 auto 12px', display:'flex', alignItems:'center', justifyContent:'center' }}>
              <MS n="check_circle" size={28} fill={1} color="#15803D"/>
            </div>
            <div style={{ fontSize:16, fontWeight:700, color:'#15803D', marginBottom:4 }}>Protocol Processed!</div>
            <div style={{ fontSize:13, color:'#166534' }}>3 exercises extracted and added to your program.</div>
          </GC>
        )}

        <div style={{ display:'flex', alignItems:'center', gap:8, marginBottom:14 }}>
          <MS n="verified_user" size={18} fill={1} color="#15803D"/>
          <span style={{ fontSize:12, color:D.onSurfVar }}>HIPAA Compliant & Encrypted Data Processing</span>
        </div>

        {scanning ? (
          <div>
            <div style={{ height:6, background:D.surfCon, borderRadius:99, overflow:'hidden', marginBottom:8 }}>
              <div style={{ height:'100%', width:`${progress}%`, background:D.primary, borderRadius:99, transition:'width 0.15s' }}/>
            </div>
            <p style={{ textAlign:'center', fontSize:12, color:D.outline }}>Scanning… {progress}%</p>
          </div>
        ) : !done ? (
          <>
            <button onClick={startScan} style={{ width:'100%', height:52, borderRadius:13, background:D.primary,
              border:'none', color:'#fff', fontSize:16, fontWeight:700, cursor:'pointer',
              display:'flex', alignItems:'center', justifyContent:'center', gap:8,
              boxShadow:`0 4px 16px ${D.primary}40` }}>
              <MS n="auto_awesome" size={20} color="#fff"/>
              Start Scan
            </button>
            <p style={{ textAlign:'center', fontSize:11, color:D.outline, marginTop:8 }}>Scan time: ~15 seconds</p>
          </>
        ) : (
          <button onClick={onBack} style={{ width:'100%', height:52, borderRadius:13, background:'#15803D',
            border:'none', color:'#fff', fontSize:16, fontWeight:700, cursor:'pointer' }}>
            View My Program
          </button>
        )}
      </div>
    </div>
  );
}

// ─── Export to window ─────────────────────────────────────────────────────────
Object.assign(window, {
  D, MS, GC, Av, MainNav, TopBar, SafeFlexLogo, BackBtn,
  DashboardScreen, ExercisesScreenV2, InsightsScreen, ProfileScreen,
  DeviceSettingsScreen, PersonalInfoScreen, UploadProtocolScreen,
});
